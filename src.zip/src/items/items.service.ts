import { Injectable,Inject } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Item } from './item.entity';
import { ItemDto} from './dto/item.dto'


@Injectable()
export class ItemsService {
  
    constructor(@InjectRepository(Item) private itemsRepository: Repository<Item>) { }

    async  createItem(item: ItemDto): Promise<ItemDto> {
        return await this.itemsRepository.save(item)
    }

    async getItems(item: Item): Promise<Item[]>
     {
        return await this.itemsRepository.find();
    }
}
