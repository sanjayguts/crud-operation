import { Body, Controller, Delete, Get, Param, Post, Put, ValidationPipe } from '@nestjs/common';
import { Item } from './item.entity';
import { ItemsService } from './items.service';
import { ItemDto } from './dto/item.dto';


@Controller('items')
export class ItemsController {

    constructor(private itmsservice: ItemsService) { }

    @Post('create')
    async create(@Body(new ValidationPipe()) itemdto: ItemDto, ) {

        return this.itmsservice.createItem(itemdto);

    }

    @Get()
    get(@Param() params) {
        return this.itmsservice.getItems(params.id);
    }

    
}
