import { ItemEntity } from './item.entity';

describe('ItemEntity', () => {
  it('should be defined', () => {
    expect(new ItemEntity()).toBeDefined();
  });
});
