import { OrderEntity } from './order.entity';

describe('OrderEntity', () => {
  it('should be defined', () => {
    expect(new OrderEntity()).toBeDefined();
  });
});
