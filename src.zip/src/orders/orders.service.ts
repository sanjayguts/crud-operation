import { Injectable, Inject } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Order } from './order.entity';
import { OrderDto } from './dto/order.dto';


@Injectable()
export class OrdersService {

 constructor(@InjectRepository(Order) private ordersRepository: Repository<Order>) { }

 
async  createorder(order: OrderDto): Promise<OrderDto> {
    return await this.ordersRepository.save(order)
}

}
