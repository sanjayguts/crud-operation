import { IsString, IsInt, IsNumber } from 'class-validator';
export class OrderDto {

    readonly customer_id: number;
  readonly product_id: number;
  readonly current_price:number;
  readonly ordered_qty:number
  

  }