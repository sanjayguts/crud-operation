import { Item } from 'src/items/item.entity';
import { User } from 'src/users/users.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne } from 'typeorm';
@Entity()
export class Order {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    customer_id:number;

    @Column()
    product_id:number;

    @Column()
    current_price: number;

    @Column() 
    ordered_qty: number;
    
    @Column() 
    total_amount: number;
    
    @ManyToOne(() => User, user => user.orders)
    public user: User[]
    @ManyToOne(() => Item, item => item.orders)
    public item: Item[]
}