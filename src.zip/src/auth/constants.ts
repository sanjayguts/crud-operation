export const jwtConstants = {
    secret: 'secret12356789',
  };